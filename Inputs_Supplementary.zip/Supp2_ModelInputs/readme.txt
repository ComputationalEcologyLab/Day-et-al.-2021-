Each subdirectory in this directory contains a complete set of input files that can be used to run one of the simulation experiments from the paper. All simulations were run using CDMetaPOP version 1.44.

Maturity tests the proportion of age 0 YY males that are mature at release

NumberandSizeofFish runs 10 increments each of fingerling and catchable-sized YY males

Release locations tests using 16 or 32 locations from which to release YY males. To release from all patches, use inputs from the StandardScenario subdirectory

StandardScenario contains the default input parameters used to mimic the real-world management strategy as closely as possible.

SuppressionScheduleandEffort varies suppression mortality from 1-100% (times gear selectivity) and tests 5 different suppression schedules.

For questions, contact Casey Day, caseycday@gmail.com